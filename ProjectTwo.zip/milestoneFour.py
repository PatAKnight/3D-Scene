from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    #Initialization for the AnimalShelter Module takes the parameters username and password.
    #Username and password are used to log into the account for the database.
    #Accesses the Database and logs in to operater the CRUD operations.
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:50025/AAC'%(username, password))
        self.database = self.client['AAC']

#Create method that creates a new record in the database.
#Takes the parameter data in the form of a dictionary and add the record to the database.
    def create(self, data):
        #Checks to ensure that the parameter is not empty
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary
            return True
        else:
            return False
        
# Read method that returns the results of a find in the database.
#Takes the parameter valuein the form of a dictionary to search within the database.
#Returns that result of the search.
    def read(self, value):
        result = self.database.animals.find(value)
        if result is not None:
            return result
        else:
            raise Exception("Nothing to return")
            
#Update method that updates a record(s) in the database.
#Takes the parameter data and updateData in the form of a dictionary. 
#data is used to search for the record(s) within the database and
#updateData is the updated information for the record(s).
    def update(self, data, updateData):
        result = self.database.animals.find(data);
        if result is not None and data is not None:
            self.database.animals.update_many(data, updateData)
            updatedRecords = self.database.animals.find(data)
            return updatedRecords
        elif result is None:
            raise Exception("Key/Value Lookup Pair is not within Database")
        else:
            raise Exception("Update Field is empty")
                            
#Delete method that deletes a record(s) in the database.
#Takes the parameter data in the form of a dictionary to search and delete record(s).
#Returns the result in the form of a JSON
    def delete(self, data):
        if data is not None:
            result = self.database.animals.delete_many(data)
            return result.deleted_count
        else:
            raise Exception("Delete Field is empty")
